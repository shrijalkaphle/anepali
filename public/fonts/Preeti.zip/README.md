
# Preeti
This font was downloaded from anepali.com.

## Author:
Unknown

## Licensing Information:
No license information provided

The fonts presented on this website are their authors' property and are either freeware, shareware, demo versions or public domain. Please look at the readme-files in the archives or check the indicated author's website for details, and contact him/her if in doubt.

If no author/license is indicated, that's because we don't have information; that doesn't mean it's free. It is highly recommended to contact the author for commercial use or for any support.

## Disclaimer:
You are allowed to use these fonts for personal projects. However, if your use is commercial, it is recommended to obtain a license from the rightful owner.

Thank you for respecting the rights of the font creators.
